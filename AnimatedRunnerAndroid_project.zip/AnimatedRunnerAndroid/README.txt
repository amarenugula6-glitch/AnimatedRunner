Animated Runner — Android Studio project starter

Open this folder in Android Studio. Allow Gradle sync, then use Build > Build Bundle(s) / APK(s) > Build APK(s).
Package: com.animrunner.game

This is a starter project, not a built or tested APK. Android Studio/SDK and a compatible JDK are required to compile it.
